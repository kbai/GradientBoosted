python gather_quiz.py ../../output_svdpp\(f\=50\)_predict\(0.89524\).dta ../../output_neighborhood_predict\(0.89802\).dta  ../FREQRBM/quizrbmfreq100_withprobe.dta ../FREQRBM/quizrbmfreq200_withprobe.dta ../RBM/quizall.dta  ../svd++3/testsvd++3log676.dta ../svd++3/testsvd++3400_with_probe.dta  ../svd++3/testsvd++3withhtu.dta  ../svd++3/testsvd++3biglrsmallregu.dta ../svd++3/testsvd++3withprobe_freq.dta ../svd++2/test200_2.dta  ../../output_timefrequencybaseline_predict\(0.92643\).dta  ../../output_timebaseline_predict\(0.95337\).dta  13
# ../../output_svdpp\(f\=50\)_predict\(0.89524\).dta	0      772
# ../../output_neighborhood_predict\(0.89802\).dta		1      595
# ../FREQRBM/quizrbmfreq100_withprobe.dta				2-6   1507
# ../FREQRBM/quizrbmfreq200_withprobe.dta				7-11  2389
# ../RBM/quizall.dta									12-16      2606
# ../svd++3/testsvd++3log676.dta						17         609
# ../svd++3/testsvd++3400_with_probe.dta				18         618
# ../svd++3/testsvd++3withhtu.dta						19         513
# ../svd++3/testsvd++3biglrsmallregu.dta				20         482
# ../svd++3/testsvd++3withprobe_freq.dta				21         497
# ../svd++2/test200_2.dta								22         560
# ../../output_timefrequencybaseline_predict\(0.92643\).dta	23     991
# ../../output_timebaseline_predict\(0.95337\).dta  13		24     687


