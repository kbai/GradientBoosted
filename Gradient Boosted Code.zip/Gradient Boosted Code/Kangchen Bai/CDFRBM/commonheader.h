#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <stdlib.h>
#include <numeric>
#include <cmath>
#define NUSER 458293
#define NMOVIE 17770
#define DATAPATH "../../data/"
