float dotprod(const vector<float>& v1, const vector<float>& v2);
