#!/bin/bash
./dividedata.bin
./a.out
./lat_gpu.bin withuserfreq.dta > withuserfreq.txt
