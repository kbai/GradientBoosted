#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include<cmath>
using namespace std;

double rmse(vector<vector<int>> &v, double mean){
	double res = 0;
	int n = v.size();
	for(vector<int> x : v){
		res += pow((mean - x[4]),2) / n;
	}
	return sqrt(res);
}

double global_mean(vector<vector<int>> &v){
	int n = v.size();
	double mean = 0;
	for(vector<int> x : v){
		mean += (double) x[4] / n;
	}
	return mean;
}

void read_data(string s, vector<vector<int>> &set){
	ifstream data(s);
	int i = 0;
	while(!data.eof()){
		data >> set[i][0] >> set[i][1] >> set[i][2] >> set[i][3] >> set[i][4];
		i++;
	}
	cout << s << " loaded." << endl;
}

int main(){
	int N1 = 94362234, N2 = 1965045, N3 = 1964391, N4 = 1374739;
	vector<vector<int>> train_set(N1, vector<int>(5, 0)), valid_set(N2, vector<int>(5, 0)), hidden_set(N3, vector<int>(5,0)), probe_set(N4, vector<int>(5,0));
	
	read_data("./1.dta", train_set);
	read_data("./2.dta", valid_set);
	read_data("./3.dta", hidden_set);
	read_data("./4.dta", probe_set);

	double mean1 = global_mean(train_set);
	double mean2 = global_mean(valid_set);
	double mean3 = global_mean(hidden_set);
	double mean4 = global_mean(probe_set);
	cout << "mean of 1.dta is " << mean1 << endl;
	cout << "mean of 2.dta is " << mean2 << endl;
	cout << "mean of 3.dta is " << mean3 << endl;
	cout << "mean of 4.dta is " << mean4 << endl;

	double mean = (mean1*N1 + mean2*N2 + mean3*N3 + mean4*N4) / (N1+N2+N3+N4);
	
	cout << "global mean is" << " " << mean << endl;
	cout << "the RMSE on 4.dta is " << rmse(probe_set, mean) << endl;


}
		
		
