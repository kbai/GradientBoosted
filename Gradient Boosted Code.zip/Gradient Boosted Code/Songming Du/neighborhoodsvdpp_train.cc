#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <stdlib.h>
#include <numeric>
#include <cmath>
#include <cstdlib>
#include <random>
#include <ctime>
#include <unordered_map>
#define NUSER 458293
#define NMOVIE 17770
#define NTIME 2243
#define NF 200 // number of latent factors
#define N1 94362233
#define N2 1965045
#define N3 1964391
#define N4 1374739
#define N5 2749898
using namespace std;


/***************************
This program trains an integrated model combined SVD++ and BellKor's neighborhood model, which corresponds to Eq.(16) of [Y. Koren, 2008].
****************************/

/*
NF = 50
#iteration = 49
rmse on probe set = 0.89583
output output_neighborhoodsvdpp_train.dta generated.

NF = 100
#iteration = 60
rmse on probe set = 0.89476
output output_neighborhoodsvdpp100_train.dta generated.

NF = 200
#iteration = 97
rmse on probe set = 0.893731
output output_neighborhoodsvdpp200_train.dta generated.
*/



default_random_engine e(time(0));

struct Feature{
    int u;
    int m;
    int t;
    int r;
    Feature(int uu, int mm, int tt, int rr) : u(uu), m(mm), t(tt), r(rr) {}
};

void load_all_data(vector<Feature> &v1, vector<Feature> &v2, vector<Feature> &v3, vector<Feature> &v4, vector<Feature> &v5, vector<float> &Tu, vector<unordered_map<int, int>> &Fut, vector<vector<Feature>> &Ru, vector<int> &Rm, vector<vector<Feature>> &Nu){
    ifstream all_dta("all.dta");
    ifstream all_idx("all.idx");
    int index;
    int uu, mm, tt, rr;
	int last_uu = 1, n_uu = 0, sum_t;
	while(all_idx >> index){
        all_dta >> uu >> mm >> tt >> rr;
		Nu[uu-1].push_back(Feature(uu-1, mm-1, tt-1, rr));;
        if(index == 1 || index == 2 || index == 3) {
			//v1.push_back(Feature(uu-1, mm-1, tt-1, rr)); 
			Ru[uu-1].push_back(Feature(uu-1, mm-1, tt-1, rr)); 
			Rm[mm-1]++;
		}
        //if(index == 2) v2.push_back(Feature(uu-1, mm-1, tt-1, rr));
        //if(index == 3) v3.push_back(Feature(uu-1, mm-1, tt-1, rr));
        if(index == 4) v4.push_back(Feature(uu-1, mm-1, tt-1, rr));
        //if(index == 5) v5.push_back(Feature(uu-1, mm-1, tt-1, rr));
		Fut[uu-1][tt-1]++;
        if(uu == last_uu){
            n_uu++;
            sum_t += tt-1;
        }
        else{
            Tu[last_uu-1] = (float)sum_t / n_uu;
            sum_t = tt-1;
            n_uu = 1;
            last_uu = uu;
        }
    }
	Tu[last_uu-1] = (float)sum_t / n_uu;
	cout << v1.size() << endl;
    cout << v2.size() << endl;
    cout << v3.size() << endl;
    cout << v4.size() << endl;
    cout << v5.size() << endl;
	all_dta.close();
	all_idx.close();
}

class Neighborhood{
private:
	float mu = 3.6095162;
	vector<float> bu = vector<float>(NUSER, 0);
	vector<float> bm = vector<float>(NMOVIE, 0);
	vector<vector<float>> wmn = vector<vector<float>>(NMOVIE, vector<float>(NMOVIE, 0));
	vector<vector<float>> cmn = vector<vector<float>>(NMOVIE, vector<float>(NMOVIE, 0));
	vector<float> bu_tilde = vector<float>(NUSER, 0);
	vector<float> bm_tilde = vector<float>(NMOVIE, 0);
	vector<vector<float>> pu = vector<vector<float>>(NUSER, vector<float>(NF, 0));
	vector<vector<float>> qm = vector<vector<float>>(NMOVIE, vector<float>(NF, 0));
	vector<vector<float>> y = vector<vector<float>>(NMOVIE, vector<float>(NF, 0));
	vector<vector<float>> Y = vector<vector<float>>(NUSER, vector<float>(NF, 0));
	vector<vector<Feature>> &Ru;
	vector<int> &Rm;
	vector<vector<Feature>> &Nu;

	float lambda1 = 25, lambda2 = 10;
	float eta_bu = 0.007, lambda_bu = 0.005;
	float eta_bm = 0.007, lambda_bm = 0.005;
	float eta_pu = 0.007, lambda_pu = 0.015;
	float eta_qm = 0.007, lambda_qm = 0.015;
	float eta_y = 0.007, lambda_y = 0.015;
	float eta_wmn = 0.001, lambda_wmn = 0.015;
	float eta_cmn = 0.001, lambda_cmn = 0.015;

public:
	Neighborhood(vector<vector<Feature>> &Ruu, vector<int> &Rmm, vector<vector<Feature>> &Nuu) : Ru(Ruu), Rm(Rmm), Nu(Nuu) {
        uniform_real_distribution<float> u(-0.005,0.005);
        for(vector<float> &v : pu) for(float &x : v) x = u(e);
        for(vector<float> &v : qm) for(float &x : v) x = u(e);
    }

	void initialize_btilde(){
		for(int u = 0; u < NUSER; u++){
			for(Feature &data : Ru[u]){
				bm_tilde[data.m] += (float)(data.r - mu) / (lambda1 + Rm[data.m]);
			}
		}
		for(int u = 0; u < NUSER; u++){
			for(Feature &data : Ru[u]){
				bu_tilde[data.u] += (float)(data.r - mu - bm_tilde[data.m]) / (lambda2 + Ru[data.u].size());
			}
		}
	}
	
	float bum_tilde(int u, int m){
		return mu + bu_tilde[u] + bm_tilde[m];
	}
	
	float r_hat(int u, int m, int t){
		float wc_term = 0, pyq_term = 0;
		float sqrtRu = sqrt(Ru[u].size()), sqrtNu = sqrt(Nu[u].size());
		for(Feature x : Ru[u]){
			int n = x.m;
			wc_term += (x.r - bum_tilde(u,n)) * wmn[m][n] / sqrtRu;
		}
		for(Feature x : Nu[u]){
			int n = x.m;
			wc_term += cmn[m][n] / sqrtNu;
		}
		for(int l = 0; l < NF; l++){
			pyq_term += (pu[u][l] + Y[u][l]) * qm[m][l];
		}
		return mu + bu[u] + bm[m] + pyq_term + wc_term;
	}

	void sgd(){
		for(int u = 0; u < NUSER; u++){
			float sqrtRu = sqrt(Ru[u].size()), sqrtNu = sqrt(Nu[u].size());
			for(Feature data : Nu[u]){
                for(int l = 0; l < NF; l++){
                    Y[u][l] += y[data.m][l] / sqrtNu;
                }
            }
			vector<float> cached_Y = Y[u];
			for(Feature &data : Ru[u]){
				int m = data.m;
				int r = data.r;
				int t = data.t;
				float eum = r - r_hat(u, m, t);
				bu[u] = bu[u] + eta_bu * (eum - lambda_bu * bu[u]);
				bm[m] = bm[m] + eta_bm * (eum - lambda_bm * bm[m]);
                for(int l = 0; l < NF; l++){
                    float cached_pu = pu[u][l], cached_qm = qm[m][l];
                    pu[u][l] = cached_pu + eta_pu * (eum * cached_qm - lambda_pu * cached_pu);
                    qm[m][l] = cached_qm + eta_qm * (eum * (cached_pu + Y[u][l]) - lambda_qm * cached_qm);
                    Y[u][l] = Y[u][l] + eta_y * (eum * cached_qm - lambda_y * Y[u][l]);
                }				
				for(Feature &x : Ru[u]){
					int n = x.m;
					if(n != m){
						wmn[m][n] = wmn[m][n] + eta_wmn * (eum * (x.r - bum_tilde(u, n)) / sqrtRu - lambda_wmn * wmn[m][n]);	
					}
				}
				for(Feature &x : Nu[u]){
					int n = x.m;
					if(n != m){
						cmn[m][n] = cmn[m][n] + eta_cmn * (eum / sqrtNu - lambda_cmn * cmn[m][n]);
					}
				}
			}
            for(Feature data : Nu[u]){
                int n = data.m;
                for(int l = 0; l < NF; l++){
                    y[n][l] = y[n][l] + (Y[u][l]-cached_Y[l])/sqrtNu + eta_y*lambda_y* Ru[u].size()*(cached_Y[l]/sqrtNu - y[n][l]);
                }
			}
		}
	}

	void learning_rate_decay(){
		float decayrate = 0.90;
		eta_bu *= decayrate;
		eta_bm *= decayrate;
		eta_pu *= decayrate;
		eta_qm *= decayrate;
		eta_y *= decayrate;
		eta_cmn *= decayrate;
		eta_wmn *= decayrate;
	}

	float rmse(vector<Feature> &set){
    	int n = set.size();
    	float res = 0;
    	for(Feature data : set){
        	res += pow((r_hat(data.u, data.m, data.t) - data.r), 2.0) / n;
		}
		return sqrt(res);
    }
	
	void predict(vector<Feature> &set, string s){
		int n = set.size();
		ofstream file(s);
		for(Feature data : set){
			file << r_hat(data.u, data.m, data.t) << endl;
		}
		file.close();
		cout << "output " << s << " generated." << endl;
	}
    void show_parameters(){
        uniform_int_distribution<int> u_random(0, NUSER-1), m_random(0, NMOVIE-1);
        for(int i = 0; i < 10; i++){
			int u = u_random(e), m = m_random(e);
            cout << "u=" << u << " ,m=" << m << " ,bu_tilde=" << bu_tilde[u] << " ,bm_tilde=" << bm_tilde[m] << " ,bu=" << bu[u] << " ,bm=" << bm[m];
			cout << " ,pu=" << pu[u][u%NF] << " ,qm=" << qm[m][u%NF] << " ,y=" << y[m][u%NF] << " ,Y=" << Y[u][u%NF] << " ,wmn=" << wmn[m][Ru[u][0].m] << " ,cmn=" << cmn[m][Nu[u][0].m] << endl;
       	}
    }
};



int main(){

	vector<Feature> train, valid, hidden, probe, qual;
	vector<float> Tu(NUSER,0);
	vector<unordered_map<int, int>> Fut(NUSER);
	vector<vector<Feature>> Ru(NUSER);
	vector<int> Rm(NMOVIE);
	vector<vector<Feature>> Nu(NUSER);
    //train.reserve(N1+N2+N3);
    //valid.reserve(N2);
    //hidden.reserve(N3);
    probe.reserve(N4);
    //qual.reserve(N5);
    load_all_data(train, valid, hidden, probe, qual, Tu, Fut, Ru, Rm, Nu);

    float testscore;
    float mintestscore = 0.94;

	Neighborhood model(Ru, Rm, Nu);
	model.initialize_btilde();

    for(int i = 0; i < 100; i++){
        cout << "#iteration = " << i << endl;
        model.sgd();
        model.show_parameters();
        model.learning_rate_decay();
        //cout << "rmse on valid set = " << model.rmse(valid) << endl;
        testscore = model.rmse(probe);
        cout << "rmse on probe set = " << testscore << endl;
        if(testscore  < mintestscore){
            mintestscore = testscore;
            model.predict(probe, "output_neighborhoodsvdpp200_train.dta");
        }
    }

}

