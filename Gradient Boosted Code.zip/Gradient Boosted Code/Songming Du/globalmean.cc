#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <stdlib.h>
#include <numeric>
#include <cmath>
#include <cstdlib>
#include <random>
#include <ctime>
#define NUSER 458293
#define NMOVIE 17770
#define NTIME 2243
#define NF 50 // number of latent factors
#define N1 94362233
#define N2 1965045
#define N3 1964391
#define N4 1374739
#define N5 2749898
using namespace std;


/***************************
This program trains a time dependent baseline predictor, i.e. Eq.10 in (Y. Koren, 2009).
It is also a component of the time dependent SVD/SVD++ model.
****************************/


void predict(string s, double x){
	ofstream file(s);
	for(int i = 0; i < N5; i++){
		file << x << endl;
	}
	file.close();
	cout << "output " << s << " generated." << endl;
}


int main(){
	for(double r = 3.67; r < 3.68; r += 0.001){
		string s = "output_mean(" + to_string(r) + ").dta";
		predict(s, r);
	}
}		

