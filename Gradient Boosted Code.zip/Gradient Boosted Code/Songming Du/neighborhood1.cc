#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <stdlib.h>
#include <numeric>
#include <cmath>
#include <cstdlib>
#include <random>
#include <ctime>
#include <unordered_map>
#define NUSER 458293
#define NMOVIE 17770
#define NTIME 2243
#define NF 200 // number of latent factors
using namespace std;



/*
rmse on train set = 0.917583
rmse on valid set = 0.921833
rmse on hidden set = 0.921225
rmse on probe set = 0.981902
*/

default_random_engine e(time(0));

struct Feature{
    int u;
    int m;
    int t;
    int r;
    Feature(int uu, int mm, int tt, int rr) : u(uu), m(mm), t(tt), r(rr) {}
};

void load_all_data(vector<Feature> &v1, vector<Feature> &v2, vector<Feature> &v3, vector<Feature> &v4, vector<Feature> &v5, vector<float> &Tu, vector<unordered_map<int, int>> &Fut, vector<vector<Feature>> &Ru, vector<int> &Rm){
    ifstream all_dta("all.dta");
    ifstream all_idx("all.idx");
    int index;
    int uu, mm, tt, rr;
	int last_uu = 1, n_uu = 0, sum_t;
	while(all_idx >> index){
        all_dta >> uu >> mm >> tt >> rr;
        if(index == 1) {
			v1.push_back(Feature(uu-1, mm-1, tt-1, rr)); 
			Ru[uu-1].push_back(Feature(uu-1, mm-1, tt-1, rr)); 
			Rm[mm-1]++;
		}
        if(index == 2) v2.push_back(Feature(uu-1, mm-1, tt-1, rr));
        if(index == 3) v3.push_back(Feature(uu-1, mm-1, tt-1, rr));
        if(index == 4) v4.push_back(Feature(uu-1, mm-1, tt-1, rr));
        if(index == 5) v5.push_back(Feature(uu-1, mm-1, tt-1, rr));
		Fut[uu-1][tt-1]++;
        if(uu == last_uu){
            n_uu++;
            sum_t += tt-1;
        }
        else{
            Tu[last_uu-1] = (float)sum_t / n_uu;
            sum_t = tt-1;
            n_uu = 1;
            last_uu = uu;
        }
    }
	Tu[last_uu-1] = (float)sum_t / n_uu;
	cout << v1.size() << endl;
    cout << v2.size() << endl;
    cout << v3.size() << endl;
    cout << v4.size() << endl;
    cout << v5.size() << endl;
	all_dta.close();
	all_idx.close();
}
/*
class TimeFrequencySVD{
private:
	float mu = 3.6095162;
	vector<float> bu = vector<float>(NUSER, 0);
	vector<float> bm = vector<float>(NMOVIE, 0);
	vector<float> au = vector<float>(NUSER, 0);
	vector<float> cu = vector<float>(NUSER, 1);
	vector<vector<float>> but = vector<vector<float>>(NUSER, vector<float>(NTIME, 0));
	vector<vector<float>> bmbin = vector<vector<float>>(NMOVIE, vector<float>(30, 0)); 
	vector<vector<float>> cut = vector<vector<float>>(NUSER, vector<float>(NTIME, 0));
	vector<vector<float>> bmf = vector<vector<float>>(NMOVIE, vector<float>(5, 0));
	vector<float> &Tu;
	vector<unordered_map<int, int>> &Fut;

	vector<vector<float>> pu = vector<vector<float>>(NUSER, vector<float>(NF,0));
	vector<vector<float>> alphau = vector<vector<float>>(NUSER, vector<float>(NF, 0));
	vector<vector<float>> qm = vector<vector<float>>(NMOVIE, vector<float>(NF, 0));
	vector<vector<vector<float>>> qmf = vector<vector<vector<float>>>(NMOVIE, vector<vector<float>>(5, vector<float>(NF, 0)));

	
	float eta_bu = 0.00267, lambda_bu = 0.0255;
	float eta_but = 0.00257, lambda_but = 0.00231;
	float eta_au = 3.11E-6, lambda_au = 3.95;
	float eta_bm = 0.000488, lambda_bm = 0.0255;
	float eta_bmbin = 0.000115, lambda_bmbin = 0.0929;
	float eta_cu = 0.00564, lambda_cu = 0.0476;
	float eta_cut = 0.00103, lambda_cut = 0.019;
	float eta_bmf = 0.00236, lambda_bmf = 1.1E-8;

	float eta_pu = 0.008, lambda_pu = 0.015;
	float eta_alphau = 1E-5, lambda_alphau = 50;
	float eta_qm = 0.008, lambda_qm = 0.015;
	float eta_qmf = 2E-5, lambda_qmf = 0.02;	


public:
    TimeFrequencySVD(vector<float> &Tuu, vector<unordered_map<int,int>> &Futt) : Tu(Tuu), Fut(Futt) {
        uniform_real_distribution<float> u(0,1);
        for(vector<float> &v : pu) for(float &x : v) x = u(e) / NF;
        for(vector<float> &v : qm) for(float &x : v) x = u(e) / NF;
    }


	float dev(int u, int t){
		return t - Tu[u] > 0 ? pow(t-Tu[u], 0.4) : - pow(Tu[u]-t, 0.4);
	}
	
	int bin(int t){
		return t / 75;
	}

	int freq(int u, int t){
		float a = 6.76;
		if(Fut[u][t] == 0) return 0;
		return log(Fut[u][t]) / log(a);
	}

	float r_hat(int u, int m, int t){
		float pq_term = 0;
		for(int l = 0; l < NF; l++){
			pq_term +=	(pu[u][l] + alphau[u][l]*dev(u,t)) * (qm[m][l] + qmf[m][freq(u,t)][l]);
		}	

		return mu + bu[u] + au[u]*dev(u,t) + but[u][t] + (bm[m] + bmbin[m][bin(t)]) * (cu[u] + cut[u][t]) + bmf[m][freq(u,t)] + pq_term;
	}
	
	void sgd(Feature &data){	
		int u = data.u;
		int m = data.m;
		int t = data.t;
		int r = data.r;
		float eum = r - r_hat(u, m, t);
		bu[u] = bu[u] + eta_bu * (eum - lambda_bu * bu[u]);
		au[u] = au[u] + eta_au * (eum * dev(u,t) - lambda_au * au[u]);
		but[u][t] = but[u][t] + eta_but * (eum - lambda_but * but[u][t]);
		bm[m] = bm[m] + eta_bm * (eum * (cu[u] + cut[u][t]) - lambda_bm * bm[m]);
		bmbin[m][bin(t)] = bmbin[m][bin(t)] + eta_bmbin * (eum * (cu[u] + cut[u][t]) -lambda_bmbin * bmbin[m][bin(t)]);
		cu[u] = cu[u] + eta_cu * (eum * (bm[m] + bmbin[m][bin(t)]) - lambda_cu * (cu[u] - 1));
		cut[u][t] = cut[u][t] + eta_cut * (eum * (bm[m] + bmbin[m][bin(t)]) - lambda_cut * cut[u][t]);
		bmf[m][freq(u,t)] = bmf[m][freq(u,t)] + eta_bmf * (eum - lambda_bmf * bmf[m][freq(u,t)]);

		for(int l = 0; l < NF; l++){
			pu[u][l] = pu[u][l] + eta_pu * (eum * (qm[m][l] + qmf[m][freq(u,t)][l]) - lambda_pu * pu[u][l]);
			qm[m][l] = qm[m][l] + eta_qm * (eum * (pu[u][l] + alphau[u][l]*dev(u,t)) - lambda_qm * qm[m][l]);
			alphau[u][l] = alphau[u][l] + eta_alphau * (eum * (qm[m][l] + qmf[m][freq(u,t)][l]) * dev(u,t) - lambda_alphau * alphau[u][l]);
			qmf[m][freq(u,t)][l] = qmf[m][freq(u,t)][l] + eta_qmf * (eum * (pu[u][l] + alphau[u][l]*dev(u,t)) - lambda_qmf * qmf[m][freq(u,t)][l]);
	
		}
	}

    void show_parameters(){
        uniform_int_distribution<int> u_random(0, NUSER-1), m_random(0, NMOVIE-1), t_random(0, NTIME-1), f_random(0, 4), l_random(0, NF-1);
        for(int i = 0; i < 10; i++){
            cout << "bu=" << bu[u_random(e)] << " ,au=" << au[u_random(e)] <<" ,but=" << but[u_random(e)][t_random(e)] << " ,bm=" << bm[m_random(e)];
			cout << " ,bmbin=" << bmbin[m_random(e)][bin(t_random(e))] << " ,cu=" << cu[u_random(e)] << " ,cut=" << cut[u_random(e)][t_random(e)];
			cout << " ,bmf=" << bmf[m_random(e)][f_random(e)] << endl;
			cout << "pu=" << pu[u_random(e)][l_random(e)] << " ,alphau=" << alphau[u_random(e)][l_random(e)];
			cout << " ,qm=" << qm[m_random(e)][l_random(e)] << " ,qmf=" << qmf[m_random(e)][f_random(e)][l_random(e)] << endl;
        }
    }

	void learning_rate_decay(){
		eta_pu *= 0.90;
		eta_qm *= 0.90;
	}

	float rmse(vector<Feature> &set){
    	int N = set.size();
    	float res = 0;
    	for(Feature data : set){
        	res += pow((r_hat(data.u, data.m, data.t) - data.r), 2.0) / N;
		}
		return sqrt(res);
    }
	
	void predict(vector<Feature> &set, string s){
		int N = set.size();
		ofstream file(s);
		for(Feature data : set){
			file << r_hat(data.u, data.m, data.t) << endl;
		}
		file.close();
		cout << "output " << s << " generated." << endl;
	}

};

*/


class Neighborhood{
private:
	float mu = 3.6095162;
	vector<float> bu = vector<float>(NUSER, 0);
	vector<float> bm = vector<float>(NMOVIE, 0);
	vector<vector<float>> wmn = vector<vector<float>>(NMOVIE, vector<float>(NMOVIE, 0));
	vector<vector<float>> cmn = vector<vector<float>>(NMOVIE, vector<float>(NMOVIE, 0));
	vector<float> bu_tilde = vector<float>(NUSER, 0);
	vector<float> bm_tilde = vector<float>(NMOVIE, 0);
	vector<vector<Feature>> &Ru;
	vector<int> &Rm;

	float lambda1 = 25, lambda2 = 10;
	float eta_bu = 0.005, lambda_bu = 0.002;
	float eta_bm = 0.005, lambda_bm = 0.002;
	float eta_wmn = 0.005, lambda_wmn = 0.002;
	float eta_cmn = 0.005, lambda_cmn = 0.002;

public:
	Neighborhood(vector<vector<Feature>> &Ruu, vector<int> &Rmm) : Ru(Ruu), Rm(Rmm) {}

	void initialize_btilde(vector<Feature> &set){
		for(Feature data : set){
			bm_tilde[data.m] += (float)(data.r - mu) / (lambda1 + Rm[data.m]);
		}
		for(Feature data : set){
			bu_tilde[data.u] += (float)(data.r - mu - bm_tilde[data.m]) / (lambda2 + Ru[data.u].size());
		}
	}
	
	float bum_tilde(int u, int m){
		return mu + bu_tilde[u] + bm_tilde[m];
	}
	
	float r_hat(int u, int m, int t){
		float w_term = 0;
		for(Feature x : Ru[u]){
			int n = x.m;
			w_term += (x.r - bum_tilde(u,n)) * wmn[m][n] / sqrt(Ru[u].size());
		}
		return mu + bu[u] + bm[m] + w_term;
	}

	void sgd(Feature &data){	
		int u = data.u;
		int m = data.m;
		int t = data.t;
		int r = data.r;
		float eum = r - r_hat(u, m, t);
		bu[u] = bu[u] + eta_bu * (eum - lambda_bu * bu[u]);
		bm[m] = bm[m] + eta_bm * (eum - lambda_bm * bm[m]);
		for(Feature x : Ru[u]){
			int n = x.m;
			wmn[m][n] = wmn[m][n] + eta_wmn * (eum * (x.r - bum_tilde(u, n)) / sqrt(Ru[u].size()) - lambda_wmn * wmn[m][n]);	
		}
	}


	float rmse(vector<Feature> &set){
    	int n = set.size();
    	float res = 0;
    	for(Feature data : set){
        	res += pow((r_hat(data.u, data.m, data.t) - data.r), 2.0) / n;
		}
		return sqrt(res);
    }
	
	void predict(vector<Feature> &set, string s){
		int n = set.size();
		ofstream file(s);
		for(Feature data : set){
			file << r_hat(data.u, data.m, data.t) << endl;
		}
		file.close();
		cout << "output " << s << " generated." << endl;
	}
    void show_parameters(){
        uniform_int_distribution<int> u_random(0, NUSER-1), m_random(0, NMOVIE-1);
        for(int i = 0; i < 50; i++){
			int u = u_random(e), m = m_random(e);
            cout << "u=" << u << " ,m=" << m << " ,bu_tilde=" << bu_tilde[u] << " ,bm_tilde=" << bm_tilde[m] << " ,bu=" << bu[u] << " ,bm=" << bm[m];
			cout << " ,wmn=" << wmn[m][Ru[u][0].m] << endl;
       	}
    }
};



int main(){

	vector<Feature> train, valid, hidden, probe, qual;
	vector<float> Tu(NUSER,0);
	vector<unordered_map<int, int>> Fut(NUSER);
	vector<vector<Feature>> Ru(NUSER);
	vector<int> Rm(NMOVIE);
    train.reserve(94362233);
    valid.reserve(1965045);
    hidden.reserve(1964391);
    probe.reserve(1374739);
    qual.reserve(2749898);
    load_all_data(train, valid, hidden, probe, qual, Tu, Fut, Ru, Rm);

    float testscore;
    float mintestscore = 0.91;

	Neighborhood model(Ru, Rm);
	model.initialize_btilde(train);

    for(int i = 0; i < 200; i++){
        cout << "#iteration = " << i << endl;
        for(int j = 0; j < 94362233; j++){
            model.sgd(train[j]);
        }
        model.show_parameters();
        //model.learning_rate_decay();
        cout << "rmse on valid set = " << model.rmse(valid) << endl;
        testscore = model.rmse(probe);
        cout << "rmse on probe set = " << testscore << endl;
        if(testscore  < mintestscore){
            mintestscore = testscore;
            model.predict(qual, "output_timefrequencysvd.dta");
        }
    }

}

